CREATE DATABASE tpdev;

/* 
To use this SQL script with the IUT database

change the "CREATE DATABASE tp_dev" to "CREATE SCHEMA tp_dev;""

*/


CREATE TABLE tp_dev.pages (page_id SERIAL PRIMARY KEY, title VARCHAR(100) NOT NULL, subtitle TEXT, content TEXT, menu_label VARCHAR(50));
CREATE TABLE tp_dev.users (user_id SERIAL PRIMARY KEY, username VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL);


INSERT INTO tp_dev.pages (title, subtitle, content, menu_label) VALUES
('Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae', 
'Duis finibus est augue, sodales mattis ex suscipit nec.', 
'<p>Quisque vestibulum dictum libero, eu pretium nisi bibendum eu. Vivamus vehicula convallis ipsum non pretium. Maecenas lacinia diam arcu, vel fringilla sapien congue a. </p><p>Nam vel mi posuere, molestie lectus ut, lobortis nulla. Curabitur maximus odio sit amet sagittis maximus. Nam fringilla leo et feugiat dapibus. Integer non turpis a leo pharetra scelerisque. Duis finibus est augue, sodales mattis ex suscipit nec.</p>', 
'Vestibulum'),
('Quisque vestibulum dictum libero, eu pretium nisi bibendum eu', 
'Morbi a maximus mauris. Integer non feugiat lectus', 
'<p>Quisque vestibulum dictum libero, eu pretium nisi bibendum eu. Vivamus vehicula convallis ipsum non pretium. Maecenas lacinia diam arcu, vel fringilla sapien congue a. </p><p>Nam vel mi posuere, molestie lectus ut, lobortis nulla. Curabitur maximus odio sit amet sagittis maximus. Nam fringilla leo et feugiat dapibus. Integer non turpis a leo pharetra scelerisque. Duis finibus est augue, sodales mattis ex suscipit nec.</p>', 
NULL);


INSERT INTO tp_dev.users(username, password) VALUES ('username', MD5('password'));