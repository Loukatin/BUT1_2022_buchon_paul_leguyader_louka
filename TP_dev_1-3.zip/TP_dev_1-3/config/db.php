<?php


require_once("constants.php");


//try to connect with the server using the database connection information in defined in constants.php
try {
    $DB = new PDO(DB_DRIVER . ':host=' . DB_HOST . ';dbname=' . DB_DATABASE, DB_USERNAME, DB_PASSWORD);
} catch (Exception $ex) {
    echo ($ex->getMessage());
    die;
}

?>