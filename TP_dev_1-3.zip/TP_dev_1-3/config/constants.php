<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

error_reporting(E_ALL);

$settings = parse_ini_file("db.ini", TRUE);


//Database connection constants
//configure here the database connection
define('DB_DRIVER', $settings['database']['driver']);
define('DB_HOST', $settings['database']['host']);
define('DB_PORT', $settings['database']['port']);
define('DB_USERNAME', $settings['database']['username']);
define('DB_PASSWORD', $settings['database']['password']);
define('DB_DATABASE', $settings['database']['schema']);

//Database tables names 

//To use with the IUT database, add "tpdev." in front of the name of the tables  (to name explicitely the schema)
define('TABLE_PAGES', 'pages');
define('TABLE_ARTICLES', 'articles');
define('TABLE_NEWS', 'news');
define('TABLE_USERS', 'users');


//webmaster email, for the contact form
define('WEBMASTER_MAIL', 'pierre.bueno@univ-rennes1.fr');


//The subfolder on the local webserver where the website is put
define ('SITE_NAME', 'TP_dev_1-3');

//Absolute path to the root of the website
define( 'ROOT_HTTP',  "http://" . $_SERVER['HTTP_HOST'] . '/' . SITE_NAME .'/');
define('ROOT_FILE', dirname(dirname(__FILE__)) . "/");  
?>