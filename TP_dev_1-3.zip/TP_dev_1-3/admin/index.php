<?php
    
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    
    error_reporting(E_ALL);

include_once("../config/constants.php");

// Include the file containing the HTML header
require_once(ROOT_FILE . "header.php");

// Icluding the file containing the menu of our website
include_once(ROOT_FILE .  "menu.php");


    // if no user is logged, but there is an attempt to access
    // to the admin inteface, fobid it by redirect the page to the login page
    if( ! isset($_SESSION["loggedin"]) || ! $_SESSION["loggedin"]){
        header("location: ../login.php");
        exit;
    }

    // Else, output the administration page


?>

<main>

    
     <div class="main-container">
        <div class=heading>
            <h1>Interface d'administration</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec maximus enim nunc, ut laoreet odio molestie quis. Donec accumsan dui nibh.</p>
        </div>
         

         
    </div>
</main>

<?php


include_once("../footer.php");

?>


