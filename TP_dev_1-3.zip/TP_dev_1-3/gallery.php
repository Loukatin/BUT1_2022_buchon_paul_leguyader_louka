<?php
require_once('config/constants.php');

// Include the file containing the HTML header
include_once(ROOT_FILE  . "header.php");

// Icluding the file containing the menu of our website
include_once(ROOT_FILE  . "menu.php");

?>

<main>

    <div class="main-container">
        <div class="heading">
            <h1>Lorem ipsum dolor sit amet</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec maximus enim nunc, ut laoreet odio molestie quis. Donec accumsan dui nibh.</p>
        </div>
        
        
        <div class="gallery-container">
            
            <?php
            // output 18 random pictures
            for($i = 0; $i < 18; $i++){
            
            ?>
            
                <div>
                <img src="https://picsum.photos/400/400?random=<?= $i ?>" alt="random_picture<?=$i?>" />
                </div>
            
            
            <?php 
            }
            ?>
            
            
        </div>
    </div>
</main>

<?php

include_once("footer.php");

?>