<?php

require_once('config/constants.php');

require_once(ROOT_FILE . "common_functions.php");


// Include the file containing the HTML header
include_once(ROOT_FILE  . "header.php");

// Icluding the file containing the menu of our website
include_once(ROOT_FILE  . "menu.php");


//get requested page ID passed by GET method. URL should be, for instance, page.php?id=1
$page_id = $_GET["id"];

/* If no page id has been passed, redirects to a 404 error page */
if(! is_numeric($page_id)){
    header("Location:404.php");
    exit;
}

//Get the requested page infos (title, subtitle, etc) using our custom function
$page = getPageByID($page_id);

?>

<main >


        <div class="main-container">
            <div class="heading">
                <h1><?= $page['title'] ?></h1>
                <p><?= $page['subtitle'] ?></p>
            </div>
      
            <?= $page['content'] ?>
        </div>


</main>

<?php

    include_once("footer.php");

?>