<?php

 require_once('config/constants.php');

// Include the file containing the HTML header
require_once(ROOT_FILE . "header.php");

// Including the file containing the menu of our website
require_once(ROOT_FILE . "menu.php");


?>

<main>

    <!-- HERO -->
    <div class="hero">
        <div class="container-md">
            <div class="row">
                <div class="hero-text">
                    <h1>Fluid jumbotron</h1>
                    <p>This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>
                </div>
                <div class="hero-img">
                    <img src="img/illu_hero.svg" class="img-fluid" alt='illustration'/>
                </div>
            </div>
        </div>
    </div>


    <!-- MAIN CONTAINER -->
    <div class="main-container">

        <div class="heading">
            <h1>Lorem ipsum dolor sit amet</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec maximus enim nunc, ut laoreet odio molestie quis. Donec accumsan dui nibh.</p>
        </div>

        <div class="card-3-grid">
            <div class="one-card-3-grid"> 
                <div class="main-card">
                    <div class="main-card-body">
                        <img src="img/card_illu1.svg" alt='illustration'/>
                        <h3>Special title treatment</h3>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="cta">Go somewhere</a>
                    </div>
                </div>
            </div>
            <div class="one-card-3-grid">
                <div class="main-card">
                    <div class="main-card-body">
                        <img src="img/card_illu2.svg" alt='illustration'/>
                        <h3>Special title treatment</h3>
                        <p>With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="cta">Go somewhere</a>
                    </div>
                </div>
            </div>
            <div class="one-card-3-grid">
                <div class="main-card">
                    <div class="main-card-body">
                        <img src="img/card_illu3.svg" alt='illustration'/>
                        <h3>Special title treatment</h3>
                        <p>With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="cta">Go somewhere</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-container-bg">
        <div>
            <h1>Lorem ipsum dolor sit amet</h1>

            <h2>Lorem ipsum dolor sit amet</h2>

            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec maximus enim nunc, ut laoreet odio molestie quis. Donec accumsan dui nibh. Mauris sollicitudin imperdiet tellus ut eleifend. In vehicula purus in tellus egestas, non commodo ante semper. Suspendisse potenti. Aliquam sed nulla velit. Maecenas non lorem porttitor, congue sapien vitae, consectetur lectus. Suspendisse eu iaculis lorem, sit amet ullamcorper diam. Donec suscipit turpis at sagittis porta. Integer egestas mattis rutrum. Proin ut volutpat mi, tempor viverra eros. In augue massa, consectetur ut faucibus id, condimentum ut leo. 
            </p>

            <h2>Lorem ipsum dolor sit amet</h2>

            <div class="image-text">
                <div>
                    <img src="img/illu1.svg" class="bg-white" alt='illustration'/>
                </div>
                <div>
                    <p>
                        Praesent convallis eleifend risus, sed hendrerit tortor ornare a. Duis sodales, justo sit amet pulvinar maximus, lectus velit aliquam ipsum, eu aliquam orci sapien quis tortor. Nam at dui placerat lacus elementum iaculis eu et arcu. Curabitur ut rhoncus magna. Praesent gravida finibus volutpat. Sed turpis mauris, porttitor vel vehicula vitae, scelerisque in est. Vestibulum in arcu a erat pharetra elementum. Mauris pellentesque ullamcorper neque, quis scelerisque sapien auctor sit amet. Proin nec quam fringilla, semper lacus dignissim, eleifend massa. Curabitur semper sapien ut tincidunt dictum. 
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="main-container">
        <div>
            <h1>Lorem ipsum dolor sit amet</h1>
            <p>
                Nam at leo vehicula, dignissim magna eu, euismod nibh. Sed mollis enim in ante finibus, nec tincidunt nunc sodales. Duis eget venenatis mi. Fusce nisi magna, pulvinar et risus non, commodo sagittis orci. Mauris id faucibus erat. Aliquam mauris ex, iaculis et maximus vitae, accumsan at tellus. Donec in arcu vitae massa fringilla cursus sed sed ipsum. Donec venenatis in leo sit amet dictum. In tincidunt congue lectus congue ultrices. Ut aliquet commodo cursus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Phasellus sodales urna quis justo viverra laoreet. 
            </p>
        </div>

    </div>

</main>

<?php


include_once(ROOT_FILE . "footer.php");

?>


