

<?php
require_once('config/constants.php');

// Include the file containing the HTML header
include_once(ROOT_FILE . "header.php");

// Icluding the file containing the menu of our website
include_once(ROOT_FILE . "menu.php");

require_once("common_functions.php");

?>

<main >
    <div class="main-container std-form">
        
        
<?php
 
    // If the user is already logged in, then redirect him
    // to the index page of the adin section (no need to log again)
    if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"]){
        header("location: admin/index.php");
        exit;
    }

    //If the login form has been submitted
    if(isset($_POST['login'])){

            // Get the username and password provided by the user through the form
            $username = $_POST['login'];
            $password = $_POST['password'];

            //Check if the couple ($username, $password) exists in the database
            $id = checkLogin($username, $password);

            //If so, then put some session variables to log the user
            // and redirect the user to the index page of the admin section
            if($id != 0){
                            
                // Store data in session variables
                $_SESSION["loggedin"] = true;
                $_SESSION["id"] = $id;
                $_SESSION["username"] = $username;                            
                
                // Redirect user to welcome page
                header("location: admin/index.php");
                exit;
            }

            // Else, if the user / password couple is not authorized, 
            // output an error message
            else{
    ?>
                 <div class="form-message error">
                      Mauvais username / mot de passe
                </div>
    <?php     
            }

    }

?>
        
        <form method="POST" action="<?=$_SERVER['PHP_SELF']?>">

            <label>Login :</label>
            <input type='text' 
                   id="login" name="login" 
                   size='40' maxlength='50'
                   pattern='[[A-Za-z0-9]{1,50}'
                   required
                   />


            <label>Mot de passe :</label>
            <input type='password' 
                   id="password" name="password" 
                   size='40' maxlength='50'
                   required
                   />

            <input type="submit" value="Se connecter"/>
        </form>

    </div>
    


</main>

<?php

    include_once("footer.php");

?>



