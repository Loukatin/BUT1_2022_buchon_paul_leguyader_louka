
<?php
    require_once("config/constants.php");
    require_once(ROOT_FILE . "common_functions.php");
?>

<nav class="main-navbar">
    <div>
        <a class="home-link" href="<?= ROOT_HTTP ?>">
            <img class="img-64px logo" src="<?= ROOT_HTTP ?>img/logo.png" alt="logo" />
        </a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="navbar-body" id="navbarNavDropdown">
            <ul>
                <li><a href="<?= ROOT_HTTP ?>index.php">Accueil</a></li>
<?php
    // Get the pages to be included in the menu (ie the one that have a menu_item)
    $pages = getMenuPages();

    //Loop on these pages and output link and menu label in a <li> HTML tag
    foreach($pages as $page){

?>
                <li><a href="<?= ROOT_HTTP ?>page.php?id=<?= $page['page_id']?>" > <?= $page['menu_label']; ?> </a></li>

<?php } ?>

                <li><a href="<?= ROOT_HTTP ?>gallery.php">Galerie</a></li>
            </ul>
            <hr class="menu-sep">
            <a class="contact-button" href="<?= ROOT_HTTP ?>index.php">Contact</a>
            
            <?php

            // If the user is logegd, then output the logout button and a link vers teh admin interface
            if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"]){
                
            ?>
            
            <a class="login-button" href="<?= ROOT_HTTP ?>logout.php">Se déconnecter</a>
            <a class="login-button" href="<?= ROOT_HTTP ?>admin/index.php">Interface admin</a>
            
            
            <?php
            
            }
            // If no user is logegd, output only a login button that points to the login.php page
            else{
            
            ?>
            
            <a class="login-button" href="<?= ROOT_HTTP ?>login.php">Se connecter</a>    
            
            <?php
            }
            ?>
            
            
            
        </div>
    </div>
</nav>