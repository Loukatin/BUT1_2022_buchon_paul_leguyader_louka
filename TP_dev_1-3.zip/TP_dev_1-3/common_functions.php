<?php


/***************************************/
/* Common functions to get objects
/* from database
/***************************************/

require_once('config/constants.php');
require_once(ROOT_FILE  . "config/db.php");





/***************************************************************************
 Returns the columns page_id and page_menu_item of every page of the table pages that has 
 a page_menu_item that is not null.
 @return array $results : An array containing the resulting couples, or an empty array if no such coupels exist.
 Each couple is described as a map with indexes page_id and page_menu_item.
 The function outputs an error message and returns null if the database request fails 
***************************************************************************/
function getMenuPages(){
    global $DB;

    $sql = "SELECT page_id, menu_label FROM " . TABLE_PAGES . " WHERE menu_label is not NULL";
    $results = [];
        
    try {
        $stmt = $DB->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();
        
        return $results;
        
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
}

/***************************************************************************
 Returns the page of the table pages that has the page_id $id if it exists, an empty array otherwise.
 @params integer $id : The id of the page.
 @return array $results : A page (the resulting row). 
 The page is described as a map indexed on the table columns.
 The return array is empty if no page of id $id exists in the table.
 The function outputs an error message and returns null if the database request fails 
***************************************************************************/
function getPageByID($id){
    global $DB;

    $sql = "SELECT * FROM " . TABLE_PAGES . " WHERE page_id = " . $id;
    $results = [];
        
    try {
        $stmt = $DB->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();
            
        if(count($results) > 0)
            return $results[0];
        
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
}



/***************************************************************************
 Returns the id of the user of username $username if the couple ($username, $password) is present in the users table,
 0 otherwise
 @return array  : The id of the user of username $username if the couple ($username, $password) is present in the users table,
 0 otherwise. The function outputs an error message and returns null if the database request fails.
***************************************************************************/
function checkLogin($username, $password){
    
    global $DB;

    $sql = "SELECT user_id, password FROM " . TABLE_USERS . " WHERE username = '" . $username . "'";

    $results = array();
        

    try {
        $stmt = $DB->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();


        var_dump($results);
        // Beware : the md5 chek on password is now deprecated (see https://www.php.net/manual/fr/ref.password.php)
        // For educational purposes only
        if(count($results)){
            if($results[0]["password"] == md5($password))
                return $results[0]['user_id'];
            else
                return 0;
        }
        
           
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }

}

?>