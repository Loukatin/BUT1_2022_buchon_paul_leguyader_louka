<?php

require_once('config/constants.php');

require_once(ROOT_FILE . "common_functions.php");


// Include the file containing the HTML header
include_once(ROOT_FILE  . "header.php");

// Icluding the file containing the menu of our website
include_once(ROOT_FILE  . "menu.php");


?>

<main >


        <div class="main-container">
            
            <div class="error404">
                <h1>
                    ERROR 404
                </h1>
            </div>
        </div>


</main>

<?php

    include_once("footer.php");

?>