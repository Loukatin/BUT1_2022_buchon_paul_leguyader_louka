    

<footer class="footer">
    <nav class="bottom-navbar">
        <ul>
            <li><a href="<?= ROOT_HTTP ?>index.php">Accueil</a></li>
            <li><a href="<?= ROOT_HTTP ?>index.php">Contact</a></li>
            <li><a href="<?= ROOT_HTTP ?>index.php">Mentions légales</a></li>

    </ul>
    </nav>
</footer>

</body>
</html>
