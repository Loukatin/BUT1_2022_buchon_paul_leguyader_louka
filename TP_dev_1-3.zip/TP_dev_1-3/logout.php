<?php

// Not a real page, just a script that unset all sessions variables and redirects to the proper page

//required to use the session variables
session_start();

// Delete the session variables used to log user 
unset($_SESSION['loggedin']);
unset($_SESSION['id']);
unset($_SESSION['username']);
 
//For safety : delete all session variables
session_destroy();

//Redirect to the public index
header("location: index.php");
exit;
?>